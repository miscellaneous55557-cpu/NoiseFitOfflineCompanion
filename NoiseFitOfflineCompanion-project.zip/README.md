# NoiseFit Offline Companion (experimental)

This is an initial BLE diagnostic scaffold for the NoiseFit Evolve Sports watch.
It scans for NoiseFit/EVOLVE devices, connects, lists GATT services and
characteristics, and requests notifications on the known custom notify
characteristic.

Known UUIDs:
- Service: `c3e6fea0-e966-1000-8000-be99c223df6a`
- Write characteristic: `c3e6fea1-e966-1000-8000-be99c223df6a`
- Notify characteristic: `c3e6fea2-e966-1000-8000-be99c223df6a`

Important:
- This build does **not** send guessed/random BLE commands.
- Time-setting and notification forwarding require reverse engineering and
  validating the exact packet formats from the original APK and watch.
- It is a diagnostic starting point, not a finished replacement app.
- Android build runs through GitHub Actions; no Gradle wrapper is included.
