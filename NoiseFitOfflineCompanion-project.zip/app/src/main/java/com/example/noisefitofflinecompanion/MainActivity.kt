package com.example.noisefitofflinecompanion

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.UUID

class MainActivity : Activity() {
    private val serviceId = UUID.fromString("c3e6fea0-e966-1000-8000-be99c223df6a")
    private val writeId = UUID.fromString("c3e6fea1-e966-1000-8000-be99c223df6a")
    private val notifyId = UUID.fromString("c3e6fea2-e966-1000-8000-be99c223df6a")
    private val cccdId = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    private lateinit var log: TextView
    private var gatt: BluetoothGatt? = null
    private var writeChar: BluetoothGattCharacteristic? = null
    private val btAdapter: BluetoothAdapter? by lazy {
        (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    }

    private fun addLog(s: String) {
        runOnUiThread { log.append("\n$s") }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        layout.addView(TextView(this).apply {
            text = "NoiseFit Offline Companion\nExperimental BLE diagnostic build"
            textSize = 20f
        })
        layout.addView(Button(this).apply {
            text = "Scan for EVOLVE SPORT"
            setOnClickListener { if (permissionsOk()) scan() else requestNeededPermissions() }
        })
        layout.addView(Button(this).apply {
            text = "Disconnect"
            setOnClickListener { gatt?.disconnect(); gatt?.close(); gatt = null; addLog("Disconnected") }
        })
        log = TextView(this).apply { text = "Ready. No protocol commands are sent automatically."; textSize = 14f }
        val scroll = ScrollView(this)
        scroll.addView(log)
        layout.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(layout)
        if (!permissionsOk()) requestNeededPermissions()
    }

    private fun permissionsOk(): Boolean {
        val needed = if (Build.VERSION.SDK_INT >= 31) arrayOf(
            Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT
        ) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        return needed.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
    }

    private fun requestNeededPermissions() {
        val needed = if (Build.VERSION.SDK_INT >= 31) arrayOf(
            Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT
        ) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        requestPermissions(needed, 41)
    }

    @Suppress("MissingPermission")
    private fun scan() {
        val adapter = btAdapter
        if (adapter == null || !adapter.isEnabled) {
            addLog("Bluetooth is unavailable or switched off.")
            return
        }
        addLog("Scanning for 12 seconds…")
        val scanner = adapter.bluetoothLeScanner ?: run { addLog("BLE scanner unavailable"); return }
        scanner.startScan(object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val device = result.device
                val name = try { device.name ?: result.scanRecord?.deviceName ?: "(unnamed)" }
                           catch (_: SecurityException) { "(permission needed)" }
                if (name.contains("EVOLVE", true) || name.contains("NOISE", true)) {
                    scanner.stopScan(this)
                    addLog("Found $name (${device.address}); connecting…")
                    connect(device)
                }
            }
            override fun onScanFailed(errorCode: Int) { addLog("Scan failed: $errorCode") }
        })
        window.decorView.postDelayed({ try { scanner.stopScan(object : ScanCallback() {}) } catch (_: Exception) {} }, 12000)
    }

    @Suppress("MissingPermission")
    private fun connect(device: BluetoothDevice) {
        gatt?.close()
        gatt = device.connectGatt(this, false, object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
                if (status != BluetoothGatt.GATT_SUCCESS) {
                    addLog("Connection error: $status")
                    g.close()
                    return
                }
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    addLog("Connected. Discovering services…")
                    g.discoverServices()
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) addLog("Disconnected from watch")
            }

            override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
                if (status != BluetoothGatt.GATT_SUCCESS) { addLog("Service discovery failed: $status"); return }
                g.services.forEach { svc ->
                    addLog("Service: ${svc.uuid}")
                    svc.characteristics.forEach { ch ->
                        addLog("  Characteristic: ${ch.uuid} properties=${ch.properties}")
                    }
                }
                val svc = g.getService(serviceId)
                writeChar = svc?.getCharacteristic(writeId)
                val notifyChar = svc?.getCharacteristic(notifyId)
                if (writeChar == null || notifyChar == null) {
                    addLog("Expected NoiseFit service/characteristics not found.")
                    return
                }
                val enabled = g.setCharacteristicNotification(notifyChar, true)
                val descriptor = notifyChar.getDescriptor(cccdId)
                if (enabled && descriptor != null) {
                    if (Build.VERSION.SDK_INT >= 33) {
                        val result = g.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
                        addLog("Notification setup requested (result=$result)")
                    } else {
                        @Suppress("DEPRECATION")
                        descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        @Suppress("DEPRECATION")
                        val result = g.writeDescriptor(descriptor)
                        addLog("Notification setup requested (result=$result)")
                    }
                } else addLog("Could not enable notifications (descriptor missing or rejected).")
            }

            override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
                addLog("Notify ${characteristic.uuid}: ${value.joinToString("-") { "%02X".format(it) }}")
            }
            @Suppress("DEPRECATION")
            override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
                characteristic.value?.let { value ->
                    addLog("Notify ${characteristic.uuid}: ${value.joinToString("-") { "%02X".format(it) }}")
                }
            }
        })
    }
}
