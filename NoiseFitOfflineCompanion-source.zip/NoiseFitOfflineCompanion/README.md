# NoiseFit Offline Companion — prototype source

An offline Android BLE diagnostic prototype for the user's NoiseFit Evolve Sports. It does not require an account and does not contact a server.

## Current features
- Scans for `EVOLVE SPORT` / BLE address `DD:27:DB:35:F5:F5`.
- Connects to custom BLE service `c3e6fea0-e966-1000-8000-be99c223df6a`.
- Finds write and notify characteristics and subscribes to notifications.
- Displays received BLE data.
- Opens Android Notification Access settings and can show recent local notification previews after permission is granted.
- Does not send unknown commands or use DFU.

## Important limitations
This is **not a finished replacement app**. Time synchronization and forwarding phone notifications to the watch are not implemented because the watch command packet formats have not yet been recovered and verified. The original app's string identifiers alone do not provide enough information to safely construct commands. No installable APK is included in this archive.

## Build an APK with GitHub Actions (no Android Studio needed)
1. Create or sign in to a GitHub account.
2. Create a new **private** repository.
3. Upload the contents of this folder to the repository's `main` branch, preserving `.github/workflows/build-apk.yml`.
4. Open the repository's **Actions** tab and select **Build debug APK**. Press **Run workflow** if it has not run automatically.
5. When the run finishes, open it and download the artifact named `NoiseFitOfflineCompanion-debug-apk`. Extract it; it contains `app-debug.apk`.
6. Transfer the APK to your Android phone and install it. Android may ask you to allow installation from that source. Only install APKs you built or trust.

Alternatively, open this folder in Android Studio and build `app` → `Tasks` → `build` → `assembleDebug`. The APK output path is `app/build/outputs/apk/debug/app-debug.apk`.

## Phone permissions
On Android 12+, grant Bluetooth scan/connect permissions when prompted. To collect phone notification previews, tap **Enable phone notification access** and enable this app in Android Settings. Notification previews stay on the phone and are not uploaded. They are not yet sent to the watch.
