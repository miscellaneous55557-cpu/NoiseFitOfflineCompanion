plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.noisefitoffline"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.noisefitoffline"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-prototype"
    }
}
