package com.example.noisefitoffline

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.ParcelUuid
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.UUID

/**
 * Offline BLE discovery prototype for the user's NoiseFit Evolve Sports.
 * Deliberately does NOT send unknown commands. Exact time/notification command frames
 * must be verified from the original app protocol before those actions can be added.
 */
class MainActivity : Activity() {
    private val serviceUuid = UUID.fromString("c3e6fea0-e966-1000-8000-be99c223df6a")
    private val writeUuid = UUID.fromString("c3e6fea1-e966-1000-8000-be99c223df6a")
    private val notifyUuid = UUID.fromString("c3e6fea2-e966-1000-8000-be99c223df6a")
    private val cccdUuid = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    private lateinit var status: TextView
    private lateinit var log: TextView
    private var gatt: BluetoothGatt? = null
    private var scanning = false

    private val adapter: BluetoothAdapter? get() = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
        root.addView(TextView(this).apply { text = "NoiseFit Offline — prototype"; textSize = 22f })
        status = TextView(this).apply { text = "Ready. Internet/login is not used by this prototype."; textSize = 16f; setPadding(0, 18, 0, 18) }
        root.addView(status)
        root.addView(Button(this).apply { text = "Scan for EVOLVE SPORT"; setOnClickListener { ensurePermissionsAndScan() } })
        root.addView(Button(this).apply { text = "Enable phone notification access"; setOnClickListener {
            try { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
            catch (_: Exception) { Toast.makeText(this@MainActivity, "Open Android Settings → Special app access → Notification access", Toast.LENGTH_LONG).show() }
        } })
        root.addView(Button(this).apply { text = "Refresh captured phone notifications"; setOnClickListener {
            val items = NotificationCaptureService.latest.toList()
            append(if (items.isEmpty()) "No phone notifications captured yet. Enable notification access, then receive a test notification." else "Recent phone notifications:\n" + items.joinToString("\n\n"))
        } })
        root.addView(Button(this).apply { text = "Disconnect"; setOnClickListener { gatt?.disconnect(); gatt?.close(); gatt = null; status.text = "Disconnected" } })
        root.addView(TextView(this).apply { text = "Activity log"; textSize = 18f; setPadding(0, 16, 0, 8) })
        log = TextView(this).apply { textSize = 13f; text = "Known service: $serviceUuid\nWrite: $writeUuid\nNotify: $notifyUuid\n\nNo unknown bytes will be transmitted." }
        val scroll = ScrollView(this); scroll.addView(log)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun append(s: String) { runOnUiThread { log.append("\n\n$s") } }

    private fun ensurePermissionsAndScan() {
        val needed = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) { requestPermissions(missing.toTypedArray(), 20); return }
        startScan()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 20 && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) startScan()
        else status.text = "Bluetooth permissions are required to scan/connect."
    }

    @Suppress("MissingPermission")
    private fun startScan() {
        val a = adapter ?: run { status.text = "Bluetooth adapter unavailable"; return }
        if (!a.isEnabled) { status.text = "Turn Bluetooth on, then tap Scan again."; return }
        val scanner = a.bluetoothLeScanner ?: run { status.text = "BLE scanner unavailable"; return }
        status.text = "Scanning for 12 seconds… keep the watch nearby."
        scanning = true
        scanner.startScan(scanCallback)
        window.decorView.postDelayed({ if (scanning) { try { scanner.stopScan(scanCallback) } catch (_: Exception) {} ; scanning = false; status.text = "Scan finished. If the watch wasn't found, tap Scan again." } }, 12_000)
    }

    private val scanCallback = object : ScanCallback() {
        @Suppress("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            val name = result.scanRecord?.deviceName ?: d.name ?: "(unnamed)"
            append("Found $name — ${d.address} — RSSI ${result.rssi} dBm")
            if (name.contains("EVOLVE", true) || d.address.equals("DD:27:DB:35:F5:F5", true)) {
                try { adapter?.bluetoothLeScanner?.stopScan(this) } catch (_: Exception) {}
                scanning = false
                connect(d)
            }
        }
        override fun onScanFailed(errorCode: Int) { scanning = false; status.text = "Scan failed: $errorCode" }
    }

    @Suppress("MissingPermission")
    private fun connect(device: BluetoothDevice) {
        status.text = "Connecting to ${device.address}…"
        gatt?.close()
        gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
    }

    private val gattCallback = object : BluetoothGattCallback() {
        @Suppress("MissingPermission")
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                runOnUiThread { status.text = "Connected. Discovering services…" }
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                runOnUiThread { status.text = "Disconnected (status $statusCode)." }
                append("Disconnected; GATT status $statusCode")
            }
        }

        @Suppress("MissingPermission")
        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            if (statusCode != BluetoothGatt.GATT_SUCCESS) { append("Service discovery failed: $statusCode"); return }
            val service = g.getService(serviceUuid)
            if (service == null) { append("Custom service not found. Services: ${g.services.map { it.uuid }}"); return }
            val ch = service.getCharacteristic(notifyUuid)
            val write = service.getCharacteristic(writeUuid)
            append("Custom service found. Write characteristic present=${write != null}; Notify characteristic present=${ch != null}.")
            if (ch != null) {
                val enabled = g.setCharacteristicNotification(ch, true)
                val descriptor = ch.getDescriptor(cccdUuid)
                if (descriptor != null) {
                    if (Build.VERSION.SDK_INT >= 33) {
                        val result = g.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
                        append("Enable-notification descriptor request result=$result")
                    } else {
                        @Suppress("DEPRECATION")
                        descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        @Suppress("DEPRECATION")
                        val result = g.writeDescriptor(descriptor)
                        append("Enable-notification descriptor request queued=$result")
                    }
                } else append("CCCD descriptor not found")
                append("Local notification registration=$enabled")
            }
            runOnUiThread { status.text = "Connected; service inspected. No commands sent." }
        }

        @Deprecated("Deprecated in Android API")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            @Suppress("DEPRECATION") val bytes = characteristic.value ?: byteArrayOf()
            append("Notification ${characteristic.uuid}: ${bytes.joinToString("-") { "%02X".format(it) }}")
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            append("Notification ${characteristic.uuid}: ${value.joinToString("-") { "%02X".format(it) }}")
        }
    }

    override fun onDestroy() {
        try { gatt?.disconnect(); gatt?.close() } catch (_: Exception) {}
        gatt = null
        super.onDestroy()
    }
}
