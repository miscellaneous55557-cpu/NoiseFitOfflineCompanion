package com.example.noisefitoffline

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.app.Notification
import android.os.Bundle
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Local-only notification capture scaffold. It does not upload notification contents.
 * Forwarding them to the watch requires the verified watch command packet format.
 */
class NotificationCaptureService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras: Bundle = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val body = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isBlank() && body.isBlank()) return
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(sbn.postTime))
        val entry = "$time · ${sbn.packageName}\n$title\n$body".take(600)
        synchronized(latest) {
            latest.add(0, entry)
            while (latest.size > 20) latest.removeAt(latest.lastIndex)
        }
    }

    companion object {
        val latest: MutableList<String> = mutableListOf()
    }
}
